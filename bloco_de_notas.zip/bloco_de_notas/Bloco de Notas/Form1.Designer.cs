﻿namespace Bloco_de_Notas
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuArquivo = new System.Windows.Forms.ToolStripMenuItem();
            this.menuArquivoNovo = new System.Windows.Forms.ToolStripMenuItem();
            this.menuArquivoSalvar = new System.Windows.Forms.ToolStripMenuItem();
            this.menuArquivoSair = new System.Windows.Forms.ToolStripMenuItem();
            this.menuEditar = new System.Windows.Forms.ToolStripMenuItem();
            this.menuEditarDesfazer = new System.Windows.Forms.ToolStripMenuItem();
            this.menuEditarCopiar = new System.Windows.Forms.ToolStripMenuItem();
            this.menuEditarColar = new System.Windows.Forms.ToolStripMenuItem();
            this.menuFormatar = new System.Windows.Forms.ToolStripMenuItem();
            this.menuFormatarLinha = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.txtTexto = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuArquivo
            // 
            this.menuArquivo.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuArquivoNovo,
            this.menuArquivoSalvar,
            this.menuArquivoSair});
            this.menuArquivo.Name = "menuArquivo";
            this.menuArquivo.Size = new System.Drawing.Size(75, 24);
            this.menuArquivo.Text = "Arquivo";
            // 
            // menuArquivoNovo
            // 
            this.menuArquivoNovo.Name = "menuArquivoNovo";
            this.menuArquivoNovo.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.menuArquivoNovo.Size = new System.Drawing.Size(182, 26);
            this.menuArquivoNovo.Text = "Novo";
            this.menuArquivoNovo.Click += new System.EventHandler(this.menuArquivoNovo_Click);
            // 
            // menuArquivoSalvar
            // 
            this.menuArquivoSalvar.Name = "menuArquivoSalvar";
            this.menuArquivoSalvar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.menuArquivoSalvar.Size = new System.Drawing.Size(224, 26);
            this.menuArquivoSalvar.Text = "Salvar";
            // 
            // menuArquivoSair
            // 
            this.menuArquivoSair.Name = "menuArquivoSair";
            this.menuArquivoSair.Size = new System.Drawing.Size(182, 26);
            this.menuArquivoSair.Text = "Sair";
            this.menuArquivoSair.Click += new System.EventHandler(this.menuArquivoSair_Click);
            // 
            // menuEditar
            // 
            this.menuEditar.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuEditarDesfazer,
            this.menuEditarCopiar,
            this.menuEditarColar});
            this.menuEditar.Name = "menuEditar";
            this.menuEditar.Size = new System.Drawing.Size(62, 24);
            this.menuEditar.Text = "Editar";
            // 
            // menuEditarDesfazer
            // 
            this.menuEditarDesfazer.Name = "menuEditarDesfazer";
            this.menuEditarDesfazer.Size = new System.Drawing.Size(150, 26);
            this.menuEditarDesfazer.Text = "Desfazer";
            // 
            // menuEditarCopiar
            // 
            this.menuEditarCopiar.Name = "menuEditarCopiar";
            this.menuEditarCopiar.Size = new System.Drawing.Size(150, 26);
            this.menuEditarCopiar.Text = "Copiar";
            // 
            // menuEditarColar
            // 
            this.menuEditarColar.Name = "menuEditarColar";
            this.menuEditarColar.Size = new System.Drawing.Size(150, 26);
            this.menuEditarColar.Text = "Colar";
            // 
            // menuFormatar
            // 
            this.menuFormatar.Checked = true;
            this.menuFormatar.CheckOnClick = true;
            this.menuFormatar.CheckState = System.Windows.Forms.CheckState.Checked;
            this.menuFormatar.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuFormatarLinha});
            this.menuFormatar.Name = "menuFormatar";
            this.menuFormatar.Size = new System.Drawing.Size(83, 24);
            this.menuFormatar.Text = "Formatar";
            // 
            // menuFormatarLinha
            // 
            this.menuFormatarLinha.Checked = true;
            this.menuFormatarLinha.CheckState = System.Windows.Forms.CheckState.Checked;
            this.menuFormatarLinha.Name = "menuFormatarLinha";
            this.menuFormatarLinha.Size = new System.Drawing.Size(224, 26);
            this.menuFormatarLinha.Text = "Quebra de Linha";
            this.menuFormatarLinha.Click += new System.EventHandler(this.menuFormatarLinha_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuArquivo,
            this.menuEditar,
            this.menuFormatar});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(822, 28);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // txtTexto
            // 
            this.txtTexto.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTexto.Location = new System.Drawing.Point(0, 31);
            this.txtTexto.Multiline = true;
            this.txtTexto.Name = "txtTexto";
            this.txtTexto.Size = new System.Drawing.Size(822, 391);
            this.txtTexto.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(822, 421);
            this.Controls.Add(this.txtTexto);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem menuArquivo;
        private System.Windows.Forms.ToolStripMenuItem menuArquivoNovo;
        private System.Windows.Forms.ToolStripMenuItem menuArquivoSalvar;
        private System.Windows.Forms.ToolStripMenuItem menuArquivoSair;
        private System.Windows.Forms.ToolStripMenuItem menuEditar;
        private System.Windows.Forms.ToolStripMenuItem menuEditarDesfazer;
        private System.Windows.Forms.ToolStripMenuItem menuEditarCopiar;
        private System.Windows.Forms.ToolStripMenuItem menuEditarColar;
        private System.Windows.Forms.ToolStripMenuItem menuFormatar;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.TextBox txtTexto;
        private System.Windows.Forms.ToolStripMenuItem menuFormatarLinha;
    }
}

