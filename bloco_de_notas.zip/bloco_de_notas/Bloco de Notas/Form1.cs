﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bloco_de_Notas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            menuFormatarLinha.Checked = true;
            txtTexto.WordWrap = true;
        }

        private void menuArquivoNovo_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show(
                "Descartar as informações atuais?",
                "Novo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (r == DialogResult.Yes) txtTexto.Clear();
        }

        private void menuArquivoSair_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show(
                "Você deseja sair?",
                "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (r == DialogResult.Yes) Application.Exit();
        }

        private void menuFormatarLinha_Click(object sender, EventArgs e)
        {
            menuFormatarLinha.Checked = !menuFormatarLinha.Checked;
            txtTexto.WordWrap = !txtTexto.WordWrap;
        }
    }
}
