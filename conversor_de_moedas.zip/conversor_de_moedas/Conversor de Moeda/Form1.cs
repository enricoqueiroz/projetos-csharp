﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Conversor_de_Moeda
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // Configurar cultura pt-BR
            System.Globalization.CultureInfo culture = new System.Globalization.CultureInfo("pt-BR");
            System.Threading.Thread.CurrentThread.CurrentCulture = culture;

            txtReais.KeyPress += txtReais_KeyPress;
            txtReais.Leave += txtReais_Leave;
        }

        public void txtReais_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permitir apenas números, vírgula e backspace
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != ',')
            {
                e.Handled = true;
            }
            // Permitir apenas uma vírgula
            if (e.KeyChar == ',' && (sender as TextBox).Text.IndexOf(',') > -1)
            {
                e.Handled = true;
            }
        }

        public void txtReais_Leave(object sender, EventArgs e)
        {
            // Formatar o valor para moeda brasileira
            if (decimal.TryParse(txtReais.Text, out decimal valor))
            {
                txtReais.Text = valor.ToString("F2");
            }
        }

        private void btnConverter_Click(object sender, EventArgs e)
        {
            decimal reais = Convert.ToDecimal(txtReais.Text);
            switch(cbxConverter.SelectedIndex)
            {
                case 0:
                    decimal dolar = 5.0m;
                    decimal reaisDolar = reais * dolar;
                    txtResultado.Text = reaisDolar.ToString("C2");
                    break;
                case 1:
                    decimal euro = 6.0m;
                    decimal reaisEuro = reais * euro;
                    txtResultado.Text = reaisEuro.ToString("C2");
                    break;
            }
        }
    }
}
