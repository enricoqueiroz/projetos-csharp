﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Contador_de_Cliques
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int contador = 0;
        private void btnContar_Click(object sender, EventArgs e)
        {
            lblContador.Text = $"Contador: {contador++}";

        }

        private void btnZerar_Click(object sender, EventArgs e)
        {
            contador = 0;
            lblContador.Text = $"Contador: {contador}";
        }
    }
}
