﻿using System;
using System.Windows.Forms;

namespace Check_in_Hotel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            pcbQuarto.Visible = chkFoto.Checked;
            gbxFotos.Enabled = chkFoto.Checked;
        }

        private void chkFoto_CheckedChanged(object sender, EventArgs e)
        {
            pcbQuarto.Visible = chkFoto.Checked;
            gbxFotos.Enabled = chkFoto.Checked;
        }

        private void rbt1_CheckedChanged(object sender, EventArgs e)
        {
            if (rbt1.Checked)
            {
                pcbQuarto.Image = Properties.Resources._1;
            }
        }

        private void rbt2_CheckedChanged(object sender, EventArgs e)
        {
            if (rbt2.Checked)
            {
                pcbQuarto.Image = Properties.Resources._2;
            }
        }

        private void rbt3_CheckedChanged(object sender, EventArgs e)
        {
            if (rbt3.Checked)
            {
                pcbQuarto.Image = Properties.Resources._3;
            }
        }

        private void btnCheckIn_Click(object sender, EventArgs e)
        {
            if (!mskTelefone.MaskCompleted)
            {
                MessageBox.Show("Por favor, preencha o número de telefone completo.", "Atenção", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                mskTelefone.Focus();
                return;
            }

            if (!mskCPF.MaskCompleted)
            {
                MessageBox.Show("Por favor, preencha o CPF completo.", "Atenção", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                mskCPF.Focus();
                return;
            }

            if (!mskNascimento.MaskCompleted)
            {
                MessageBox.Show("Por favor, preencha a data de nascimento completa.", "Atenção", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                mskNascimento.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtNome.Text))
            {
                MessageBox.Show("Por favor, informe o nome completo.", "Atenção", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNome.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                MessageBox.Show("Por favor, informe o e-mail.", "Atenção", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtEmail.Focus();
                return;
            }

            string tipoQuarto = "";
            if (rbtStandard.Checked) tipoQuarto = "Standard";
            else if (rbtExecutivo.Checked) tipoQuarto = "Executivo";
            else if (rbtSuite.Checked) tipoQuarto = "Suíte";

            if (tipoQuarto == "")
            {
                MessageBox.Show("Por favor, selecione um tipo de quarto.", "Atenção", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult resposta = MessageBox.Show("Deseja fazer outro check-in?", "Novo Check-in", 
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resposta == DialogResult.Yes)
            {
                LimparFormulario();
            }
            else
            {
                MessageBox.Show("Check-in finalizado!", "Informação",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void LimparFormulario()
        {
            txtNome.Clear();
            txtEmail.Clear();
            mskTelefone.Clear();
            mskCPF.Clear();
            mskNascimento.Clear();
            rbtStandard.Checked = false;
            rbtExecutivo.Checked = false;
            rbtSuite.Checked = false;
            rbt1.Checked = false;
            rbt2.Checked = false;
            rbt3.Checked = false;
            chkFoto.Checked = false;
            txtNome.Focus();
        }
    }
}