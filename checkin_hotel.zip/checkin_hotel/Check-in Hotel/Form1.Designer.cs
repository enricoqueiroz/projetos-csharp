﻿namespace Check_in_Hotel
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.mskTelefone = new System.Windows.Forms.MaskedTextBox();
            this.mskCPF = new System.Windows.Forms.MaskedTextBox();
            this.mskNascimento = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.gbxTipo = new System.Windows.Forms.GroupBox();
            this.rbtSuite = new System.Windows.Forms.RadioButton();
            this.rbtExecutivo = new System.Windows.Forms.RadioButton();
            this.rbtStandard = new System.Windows.Forms.RadioButton();
            this.pcbQuarto = new System.Windows.Forms.PictureBox();
            this.btnCheckin = new System.Windows.Forms.Button();
            this.gbxFotos = new System.Windows.Forms.GroupBox();
            this.rbt3 = new System.Windows.Forms.RadioButton();
            this.rbt2 = new System.Windows.Forms.RadioButton();
            this.rbt1 = new System.Windows.Forms.RadioButton();
            this.chkFoto = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.gbxTipo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcbQuarto)).BeginInit();
            this.gbxFotos.SuspendLayout();
            this.SuspendLayout();
            // 
            // mskTelefone
            // 
            this.mskTelefone.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.mskTelefone.Location = new System.Drawing.Point(130, 96);
            this.mskTelefone.Mask = "(99) 00000-0000";
            this.mskTelefone.Name = "mskTelefone";
            this.mskTelefone.Size = new System.Drawing.Size(132, 26);
            this.mskTelefone.TabIndex = 0;
            // 
            // mskCPF
            // 
            this.mskCPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.mskCPF.Location = new System.Drawing.Point(93, 139);
            this.mskCPF.Mask = "000.000.000-00";
            this.mskCPF.Name = "mskCPF";
            this.mskCPF.Size = new System.Drawing.Size(121, 26);
            this.mskCPF.TabIndex = 1;
            // 
            // mskNascimento
            // 
            this.mskNascimento.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.mskNascimento.Location = new System.Drawing.Point(156, 190);
            this.mskNascimento.Mask = "00/00/0000";
            this.mskNascimento.Name = "mskNascimento";
            this.mskNascimento.Size = new System.Drawing.Size(91, 26);
            this.mskNascimento.TabIndex = 2;
            this.mskNascimento.ValidatingType = typeof(System.DateTime);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(29, 140);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "CPF:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(29, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Telefone:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(29, 191);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "Nascimento:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(220, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(159, 25);
            this.label4.TabIndex = 6;
            this.label4.Text = "Nome Completo:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.Location = new System.Drawing.Point(268, 97);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 25);
            this.label5.TabIndex = 7;
            this.label5.Text = "E-mail:";
            // 
            // txtNome
            // 
            this.txtNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtNome.Location = new System.Drawing.Point(385, 141);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(158, 26);
            this.txtNome.TabIndex = 8;
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtEmail.Location = new System.Drawing.Point(341, 96);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(202, 26);
            this.txtEmail.TabIndex = 9;
            // 
            // gbxTipo
            // 
            this.gbxTipo.Controls.Add(this.rbtSuite);
            this.gbxTipo.Controls.Add(this.rbtExecutivo);
            this.gbxTipo.Controls.Add(this.rbtStandard);
            this.gbxTipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.gbxTipo.Location = new System.Drawing.Point(566, 97);
            this.gbxTipo.Name = "gbxTipo";
            this.gbxTipo.Size = new System.Drawing.Size(200, 135);
            this.gbxTipo.TabIndex = 10;
            this.gbxTipo.TabStop = false;
            this.gbxTipo.Text = "Tipo de Quarto";
            // 
            // rbtSuite
            // 
            this.rbtSuite.AutoSize = true;
            this.rbtSuite.Location = new System.Drawing.Point(6, 97);
            this.rbtSuite.Name = "rbtSuite";
            this.rbtSuite.Size = new System.Drawing.Size(78, 29);
            this.rbtSuite.TabIndex = 2;
            this.rbtSuite.TabStop = true;
            this.rbtSuite.Text = "Suíte";
            this.rbtSuite.UseVisualStyleBackColor = true;
            // 
            // rbtExecutivo
            // 
            this.rbtExecutivo.AutoSize = true;
            this.rbtExecutivo.Location = new System.Drawing.Point(6, 64);
            this.rbtExecutivo.Name = "rbtExecutivo";
            this.rbtExecutivo.Size = new System.Drawing.Size(118, 29);
            this.rbtExecutivo.TabIndex = 1;
            this.rbtExecutivo.TabStop = true;
            this.rbtExecutivo.Text = "Executivo";
            this.rbtExecutivo.UseVisualStyleBackColor = true;
            // 
            // rbtStandard
            // 
            this.rbtStandard.AutoSize = true;
            this.rbtStandard.Location = new System.Drawing.Point(6, 29);
            this.rbtStandard.Name = "rbtStandard";
            this.rbtStandard.Size = new System.Drawing.Size(113, 29);
            this.rbtStandard.TabIndex = 0;
            this.rbtStandard.TabStop = true;
            this.rbtStandard.Text = "Standard";
            this.rbtStandard.UseVisualStyleBackColor = true;
            // 
            // pcbQuarto
            // 
            this.pcbQuarto.Location = new System.Drawing.Point(271, 191);
            this.pcbQuarto.Name = "pcbQuarto";
            this.pcbQuarto.Size = new System.Drawing.Size(272, 182);
            this.pcbQuarto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcbQuarto.TabIndex = 11;
            this.pcbQuarto.TabStop = false;
            // 
            // btnCheckin
            // 
            this.btnCheckin.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.btnCheckin.Location = new System.Drawing.Point(566, 238);
            this.btnCheckin.Name = "btnCheckin";
            this.btnCheckin.Size = new System.Drawing.Size(200, 135);
            this.btnCheckin.TabIndex = 12;
            this.btnCheckin.Text = "Check-in";
            this.btnCheckin.UseVisualStyleBackColor = true;
            this.btnCheckin.Click += new System.EventHandler(this.btnCheckIn_Click);
            // 
            // gbxFotos
            // 
            this.gbxFotos.Controls.Add(this.rbt3);
            this.gbxFotos.Controls.Add(this.rbt2);
            this.gbxFotos.Controls.Add(this.rbt1);
            this.gbxFotos.Location = new System.Drawing.Point(34, 273);
            this.gbxFotos.Name = "gbxFotos";
            this.gbxFotos.Size = new System.Drawing.Size(200, 100);
            this.gbxFotos.TabIndex = 13;
            this.gbxFotos.TabStop = false;
            this.gbxFotos.Text = "Fotos dos Quartos";
            // 
            // rbt3
            // 
            this.rbt3.AutoSize = true;
            this.rbt3.Location = new System.Drawing.Point(6, 73);
            this.rbt3.Name = "rbt3";
            this.rbt3.Size = new System.Drawing.Size(58, 20);
            this.rbt3.TabIndex = 2;
            this.rbt3.TabStop = true;
            this.rbt3.Text = "Suite";
            this.rbt3.UseVisualStyleBackColor = true;
            this.rbt3.CheckedChanged += new System.EventHandler(this.rbt3_CheckedChanged);
            // 
            // rbt2
            // 
            this.rbt2.AutoSize = true;
            this.rbt2.Location = new System.Drawing.Point(6, 47);
            this.rbt2.Name = "rbt2";
            this.rbt2.Size = new System.Drawing.Size(86, 20);
            this.rbt2.TabIndex = 1;
            this.rbt2.TabStop = true;
            this.rbt2.Text = "Executivo";
            this.rbt2.UseVisualStyleBackColor = true;
            this.rbt2.CheckedChanged += new System.EventHandler(this.rbt2_CheckedChanged);
            // 
            // rbt1
            // 
            this.rbt1.AutoSize = true;
            this.rbt1.Location = new System.Drawing.Point(6, 21);
            this.rbt1.Name = "rbt1";
            this.rbt1.Size = new System.Drawing.Size(83, 20);
            this.rbt1.TabIndex = 0;
            this.rbt1.TabStop = true;
            this.rbt1.Text = "Standard";
            this.rbt1.UseVisualStyleBackColor = true;
            this.rbt1.CheckedChanged += new System.EventHandler(this.rbt1_CheckedChanged);
            // 
            // chkFoto
            // 
            this.chkFoto.AutoSize = true;
            this.chkFoto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.chkFoto.Location = new System.Drawing.Point(34, 238);
            this.chkFoto.Name = "chkFoto";
            this.chkFoto.Size = new System.Drawing.Size(127, 24);
            this.chkFoto.TabIndex = 14;
            this.chkFoto.Text = "Mostrar Foto";
            this.chkFoto.UseVisualStyleBackColor = true;
            this.chkFoto.CheckedChanged += new System.EventHandler(this.chkFoto_CheckedChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.DarkOrchid;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.label6.Location = new System.Drawing.Point(191, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(388, 48);
            this.label6.TabIndex = 15;
            this.label6.Text = "Seleção de Quartos";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(778, 400);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.chkFoto);
            this.Controls.Add(this.gbxFotos);
            this.Controls.Add(this.btnCheckin);
            this.Controls.Add(this.pcbQuarto);
            this.Controls.Add(this.gbxTipo);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.mskNascimento);
            this.Controls.Add(this.mskCPF);
            this.Controls.Add(this.mskTelefone);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Seleção de Quartos";
            this.gbxTipo.ResumeLayout(false);
            this.gbxTipo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcbQuarto)).EndInit();
            this.gbxFotos.ResumeLayout(false);
            this.gbxFotos.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox mskTelefone;
        private System.Windows.Forms.MaskedTextBox mskCPF;
        private System.Windows.Forms.MaskedTextBox mskNascimento;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.GroupBox gbxTipo;
        private System.Windows.Forms.RadioButton rbtSuite;
        private System.Windows.Forms.RadioButton rbtExecutivo;
        private System.Windows.Forms.RadioButton rbtStandard;
        private System.Windows.Forms.PictureBox pcbQuarto;
        private System.Windows.Forms.Button btnCheckin;
        private System.Windows.Forms.GroupBox gbxFotos;
        private System.Windows.Forms.RadioButton rbt3;
        private System.Windows.Forms.RadioButton rbt2;
        private System.Windows.Forms.RadioButton rbt1;
        private System.Windows.Forms.CheckBox chkFoto;
        private System.Windows.Forms.Label label6;
    }
}

