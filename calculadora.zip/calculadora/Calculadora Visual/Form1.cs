﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora_Visual
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Variáveis para cálculo
        private decimal numero1 = 0;
        private decimal numero2 = 0;
        private string operacao = "";
        private bool novaOperacao = true;

        private void AdicionarDigito(string digito)
        {
            if (novaOperacao)
            {
                txtDisplay.Clear();
                novaOperacao = false;
            }

            // Se o display já tiver vírgula e o usuário tentar adicionar outra
            if (digito == "," && txtDisplay.Text.Contains(","))
            {
                return;
            }

            // Adicionar o dígito
            txtDisplay.Text += digito;
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            AdicionarDigito("0");
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            AdicionarDigito("1");
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            AdicionarDigito("2");
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            AdicionarDigito("3");
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            AdicionarDigito("4");
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            AdicionarDigito("5");
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            AdicionarDigito("6");
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            AdicionarDigito("7");
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            AdicionarDigito("8");
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            AdicionarDigito("9");
        }

        private void btnVirgula_Click(object sender, EventArgs e)
        {
            AdicionarDigito(",");
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            PrepararOperacao("+");
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            PrepararOperacao("-");
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            PrepararOperacao("*");
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            PrepararOperacao("/");
        }

        private void btnPotencia_Click(object sender, EventArgs e)
        {
            PrepararOperacao("^");
        }
        private void PrepararOperacao(string op)
        {
            if (decimal.TryParse(txtDisplay.Text, out numero1))
            {
                operacao = op;
                novaOperacao = true;
            }
            else
            {
                MessageBox.Show("Digite um número válido!", "Erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnIgual_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(operacao))
            {
                return;
            }

            if (decimal.TryParse(txtDisplay.Text, out numero2))
            {
                decimal resultado = 0;
                bool erro = false;

                // Usar switch-case para as operações
                switch (operacao)
                {
                    case "+":
                        resultado = numero1 + numero2;
                        break;
                    case "-":
                        resultado = numero1 - numero2;
                        break;
                    case "*":
                        resultado = numero1 * numero2;
                        break;
                    case "/":
                        if (numero2 == 0)
                        {
                            MessageBox.Show("Não é possível dividir por zero!", "Erro",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            erro = true;
                        }
                        else
                        {
                            resultado = numero1 / numero2;
                        }
                        break;
                    case "^":
                        if (numero1 == 0 && numero2 <= 0)
                        {
                            MessageBox.Show("Não é possível calcular 0 elevado a um número menor ou igual a zero!", "Erro",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            erro = true;
                        }
                        else
                        {
                            resultado = (decimal)Math.Pow((double)numero1, (double)numero2);
                        }
                        resultado = (decimal)Math.Pow((double)numero1, (double)numero2);
                        break;
                }

                if (!erro)
                {
                    txtDisplay.Text = resultado.ToString();
                    operacao = "";
                    novaOperacao = true;
                }
            }
            else
            {
                MessageBox.Show("Digite um número válido!", "Erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRaiz_Click(object sender, EventArgs e)
        {
            if (decimal.TryParse(txtDisplay.Text, out decimal numero))
            {
                if (numero < 0)
                {
                    MessageBox.Show("Não é possível calcular raiz de número negativo!", "Erro",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    decimal resultado = (decimal)Math.Sqrt((double)numero);
                    txtDisplay.Text = resultado.ToString();
                    novaOperacao = true;
                }
            }
            else
            {
                MessageBox.Show("Digite um número válido!", "Erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnQuadrado_Click(object sender, EventArgs e)
        {
            if (decimal.TryParse(txtDisplay.Text, out decimal numero))
            {
                decimal resultado = numero * numero;
                txtDisplay.Text = resultado.ToString();
                novaOperacao = true;
            }
            else
            {
                MessageBox.Show("Digite um número válido!", "Erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtDisplay.Clear();
            numero1 = 0;
            numero2 = 0;
            operacao = "";
            novaOperacao = true;
            txtDisplay.Text = "0";
        }

        private void txtDisplay_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                btnLimpar_Click(null, null);
            }
            else if (e.KeyCode == Keys.Enter)
            {
                btnIgual_Click(null, null);
            }
        }
    }
}
