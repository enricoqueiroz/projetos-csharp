﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cadastro_Clientes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // Configurar cultura pt-BR
            System.Globalization.CultureInfo culture =
            new System.Globalization.CultureInfo("pt-BR");
            System.Threading.Thread.CurrentThread.CurrentCulture = culture;
        }

        private void txtCPF_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permitir apenas números e Backspace
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
                return;
            }

            // Aplicar máscara automaticamente
            TextBox txt = (TextBox)sender;

            if (txt.Text.Length == 3 || txt.Text.Length == 7)
            {
                txt.Text += ".";
                txt.SelectionStart = txt.Text.Length;
            }
            else if (txt.Text.Length == 11)
            {
                txt.Text += "-";
                txt.SelectionStart = txt.Text.Length;
            }

            // Limitar a 14 caracteres (000.000.000-00)
            if (txt.Text.Length >= 14 && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void txtTelefone_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permitir apenas números e Backspace
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
                return;
            }

            TextBox txt = (TextBox)sender;

            if (txt.Text.Length == 0)
            {
                txt.Text = "(";
                txt.SelectionStart = txt.Text.Length;
            }
            else if (txt.Text.Length == 3)
            {
                txt.Text += ") ";
                txt.SelectionStart = txt.Text.Length;
            }
            else if (txt.Text.Length == 9)
            {
                txt.Text += "-";
                txt.SelectionStart = txt.Text.Length;
            }

            // Limitar a 15 caracteres ((00) 00000-0000)
            if (txt.Text.Length >= 15 && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void txtDataNascimento_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permitir apenas números e Backspace
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
                return;
            }

            TextBox txt = (TextBox)sender;

            if (txt.Text.Length == 2 || txt.Text.Length == 5)
            {
                txt.Text += "/";
                txt.SelectionStart = txt.Text.Length;
            }

            // Limitar a 10 caracteres (dd/MM/yyyy)
            if (txt.Text.Length >= 10 && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void txtLimiteCredito_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox txt = (TextBox)sender;

            // Permitir números, Backspace, vírgula e ponto (para colar)
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 8 && e.KeyChar != ',' && e.KeyChar != '.')
            {
                e.Handled = true;
                return;
            }

            // Se for ponto, converter para vírgula
            if (e.KeyChar == '.')
            {
                e.KeyChar = ',';
            }

            // Permitir apenas uma vírgula
            if (e.KeyChar == ',' && txt.Text.Contains(","))
            {
                e.Handled = true;
            }
        }

        private void txtLimiteCredito_Leave(object sender, EventArgs e)
        {
            TextBox txt = (TextBox)sender;
            if (!string.IsNullOrEmpty(txt.Text))
            {
                // Formatar como moeda
                if (decimal.TryParse(txt.Text, out decimal valor))
                {
                    txt.Text = valor.ToString("C");
                }
            }
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            // Validar campos obrigatórios
            if (string.IsNullOrWhiteSpace(txtNome.Text))
            {
                MessageBox.Show("Informe o nome do cliente!", "Erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNome.Focus();
                return;
            }

            if (cmbTipoCliente.SelectedIndex == -1)
            {
                MessageBox.Show("Selecione o tipo de cliente!", "Erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                cmbTipoCliente.Focus();
                return;
            }

            // Validar CPF
            if (txtCPF.Text.Length != 14)
            {
                MessageBox.Show("CPF inválido! Informe um CPF completo.", "Erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCPF.Focus();
                return;
            }

            // Validar telefone
            if (txtTelefone.Text.Length != 15)
            {
                MessageBox.Show("Telefone inválido! Informe um telefone completo.", "Erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTelefone.Focus();
                return;
            }

            // Validar data
            if (txtDataNascimento.Text.Length != 10)
            {
                MessageBox.Show("Data inválida! Informe uma data completa.", "Erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDataNascimento.Focus();
                return;
            }

            // Validar limite de crédito
            decimal limite;
            if (!decimal.TryParse(txtLimiteCredito.Text.Replace("R$", "").Replace(" ", "").Trim(),
                out limite))
            {
                MessageBox.Show("Limite de crédito inválido!", "Erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtLimiteCredito.Focus();
                return;
            }

            // Usar switch-case para tipo de cliente
            string tipoCliente = cmbTipoCliente.SelectedItem.ToString();
            string mensagem;

            switch (tipoCliente)
            {
                case "Pessoa Física":
                    mensagem = "Cliente Pessoa Física cadastrado com sucesso!\n\n";
                    mensagem += "Nome: " + txtNome.Text + "\n";
                    mensagem += "CPF: " + txtCPF.Text + "\n";
                    mensagem += "Limite: " + limite.ToString("C");
                    break;

                case "Pessoa Jurídica":
                    mensagem = "Cliente Pessoa Jurídica cadastrado com sucesso!\n\n";
                    mensagem += "Nome: " + txtNome.Text + "\n";
                    // Para PJ, o CPF seria CNPJ
                    mensagem += "CNPJ: " + txtCPF.Text + "\n";
                    mensagem += "Limite: " + limite.ToString("C");
                    break;

                case "VIP":
                    mensagem = "Cliente VIP cadastrado com sucesso!\n\n";
                    mensagem += "Nome: " + txtNome.Text + "\n";
                    mensagem += "CPF: " + txtCPF.Text + "\n";
                    // Clientes VIP têm limite ilimitado
                    mensagem += "Limite: ILIMITADO";
                    break;

                default:
                    mensagem = "Tipo de cliente não reconhecido!";
                    break;
            }

            // Exibir resultado
            lblResultado.Text = mensagem;
            MessageBox.Show(mensagem, "Sucesso", MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            // Limpar formulário
            LimparFormulario();
        }
        private void LimparFormulario()
        {
            txtNome.Clear();
            txtCPF.Clear();
            txtTelefone.Clear();
            txtDataNascimento.Clear();
            cmbTipoCliente.SelectedIndex = -1;
            txtLimiteCredito.Clear();
            lblResultado.Clear();
            txtNome.Focus();
        }
    }

}
