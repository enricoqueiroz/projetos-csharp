﻿using System;
using System.Windows.Forms;

namespace Sistema_Biblioteca
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnValidar_Click(object sender, EventArgs e)
        {
            try
            {
                // Validação e conversão do número de dias usando txtEmprestimo
                if (!int.TryParse(txtEmprestimo.Text, out int dias))
                {
                    throw new FormatException("O campo 'Dias de Empréstimo' deve conter um número inteiro válido.");
                }

                // Validar se o nome do livro ou do leitor estão vazios
                if (string.IsNullOrWhiteSpace(txtLivro.Text) || string.IsNullOrWhiteSpace(txtLeitor.Text))
                {
                    MessageBox.Show("Por favor, preencha o nome do livro e do leitor.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Validar se os dias estão entre 1 e 30 com MessageBox YesNo
                if (dias < 1 || dias > 30)
                {
                    DialogResult resposta = MessageBox.Show(
                        "O número de dias excede o limite normal de 30 dias. Deseja liberar mesmo assim?",
                        "Confirmação de Prazo",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question
                    );

                    if (resposta == DialogResult.No)
                    {
                        txtEmprestimo.Focus();
                        txtEmprestimo.SelectAll();
                        return;
                    }
                }

                // Exibir a data prevista de devolução formatada no lblDevolucao[cite: 8]
                DateTime dataDevolucao = DateTime.Now.AddDays(dias);
                lblDevolucao.Text = $"Devolução: {dataDevolucao:dd/MM/yyyy}";
            }
            // Tratamento específico para erros de formato numérico[cite: 8]
            catch (FormatException ex)
            {
                MessageBox.Show(ex.Message, "Erro de Formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEmprestimo.Focus();
                txtEmprestimo.SelectAll();
            }
            // Tratamento genérico para qualquer outra exceção[cite: 8]
            catch (Exception ex)
            {
                MessageBox.Show($"Ocorreu um erro inesperado: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // Bloco executado independentemente de erro ou sucesso para atualizar o lblStatus[cite: 8]
                lblStatus.Text = "Status: Empréstimo finalizado";
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            // Zera os campos de texto
            txtLivro.Clear();
            txtLeitor.Clear();
            txtEmprestimo.Clear();

            // Oculta/reseta os resultados[cite: 8]
            lblDevolucao.Text = "Devolução:";
            lblStatus.Text = "Status:";

            // Retorna o foco para o primeiro campo
            txtLivro.Focus();
        }
    }
}